<div class="jumbotron">
	<h1>CMS!</h1>
	<p class="lead">
		Cras justo odio, dapibus ac facilisis in, egestas eget quam. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet.
	</p>
	<p>
		<a class="btn btn-lg btn-success" href="#" role="button">Get started today</a>
	</p>
</div>

<div class="row">
	<div class="col-lg-4">
		<h2>Edit Page Content</h2>
		<p class="text-danger">
			Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
		</p>
		<p>
			Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
		</p>
		<p>
			<a class="btn btn-primary" href="#" role="button">View details »</a>
		</p>
	</div>
	<div class="col-lg-4">
		<h2>Careful with SEO</h2>
		<p>
			Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus. Etiam porta sem malesuada magna mollis euismod. Donec sed odio dui.
		</p>
		<p>
			<a class="btn btn-primary" href="#" role="button">View details »</a>
		</p>
	</div>
	<div class="col-lg-4">
		<h2>Heading</h2>
		<p>
			Donec sed odio dui. Cras justo odio, dapibus ac facilisis in, egestas eget quam. Vestibulum id ligula porta felis euismod semper. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa.
		</p>
		<p>
			<a class="btn btn-primary" href="#" role="button">View details »</a>
		</p>
	</div>
</div>