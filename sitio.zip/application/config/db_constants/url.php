<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 |--------------------------------------------------------------------------
 | URL
 |--------------------------------------------------------------------------
 |
 */

define('HOME_PAGE', 'home');
define('INDUSTRIAL_PAGE', 'industrial');
define('CONSTRUCTION_PAGE', 'construction');
define('AGRIBUSINESS_PAGE', 'agribusiness');
define('LOCATIONS_PAGE', 'locations');
define('SERVICES_PAGE', 'services');
define('ABOUT_US_PAGE', 'about_us');






/* End of file n.pewhp */
/* Location: ./application/config/db_constants/new.php */
