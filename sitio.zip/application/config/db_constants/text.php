<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 |--------------------------------------------------------------------------
 | TABLE TEXT
 |--------------------------------------------------------------------------
 |
 */

define('TEXT_TABLE', 'st_text');

define('TEXT_ID', 'text_id');
define('TEXT_DESCRIPTION', 'text_description');
define('TEXT_PAGE', 'text_page');
define('TEXT_ORDER', 'text_order');
define('TEXT_TYPE', 'text_type');


/* End of file text.php */
/* Location: ./application/config/db_constants/text.php */
