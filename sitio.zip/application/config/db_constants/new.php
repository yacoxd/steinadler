<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 |--------------------------------------------------------------------------
 | TABLE NEW
 |--------------------------------------------------------------------------
 |
 */

define('NEW_TABLE', 'st_new');

define('NEW_ID', 'new_id');
define('NEW_TITLE', 'new_title');
define('NEW_DESCRIPTION', 'new_descripton');
define('NEW_DATE', 'new_date');
define('NEW_PAGE', 'new_page');
define('NEW_USER_CREATED', 'new_user_created');
define('NEW_DATE_CREATED', 'new_date_created');
define('NEW_USER_MODIFIED', 'new_user_modified');
define('NEW_DATE_MODIFIED', 'new_date_modified');



/* End of file n.pewhp */
/* Location: ./application/config/db_constants/new.php */
