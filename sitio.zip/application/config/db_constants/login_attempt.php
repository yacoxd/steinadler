<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 |--------------------------------------------------------------------------
 | TABLE LOGIN ATTEMPT
 |--------------------------------------------------------------------------
 |
 */

define('LOGIN_ATTEMPT_TABLE', 'st_login_attempt');

define('LOGIN_ATTEMPT_ID', 'at_id');
define('LOGIN_ATTEMPT_IP_ADDRESS', 'at_ip_address');
define('LOGIN_ATTEMPT_TIME', 'at_time');
define('LOGIN_ATTEMPT_USER', 'at_user');


/* End of file .php */
/* Location: ./application/config/db_constants/.php */
