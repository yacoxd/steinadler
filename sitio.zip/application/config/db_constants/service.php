<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
 |--------------------------------------------------------------------------
 | TABLE LANGUAGE
 |--------------------------------------------------------------------------
 |
 */

define('SERVICE_TABLE', 'st_service');

define('SERVICE_ID', 'sv_id');
define('SERVICE_TITLE', 'sv_title');
define('SERVICE_DESCRIPTION', 'sv_description');
define('SERVICE_PAGE', 'sv_page');


 


/* End of file language.php */
/* Location: ./application/config/db_constants/language.php */
